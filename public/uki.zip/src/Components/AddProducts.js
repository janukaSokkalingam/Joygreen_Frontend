import React, { Component } from "react";
 
import { Card, CardContent, Grid, FormControl, Typography, TextField ,InputLabel,Button} from '@material-ui/core';
 
import Select from '@material-ui/core/Select';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import AddBoxIcon from '@material-ui/icons/AddBox';
import SaveIcon from '@material-ui/icons/Save';
import ReplayIcon from '@material-ui/icons/Replay';
import ListIcon from '@material-ui/icons/List';
import ProductService from "./Service/ProductService";
// import ProductService from "./service/ProductService";

 


const style = {
  root: {
    minWidth: 275,
    backgroundColor:'white',
    marginTop: 20,
    color: '#000000 '
  },
}

const style1= {
  root1: {
     
    backgroundColor:'#000000',
    marginTop: 50,
    color: '#000000 '
  },
}
 

 
         
        
      
      export default class AddProduct extends Component {
        constructor(props) {
          super(props);
      
          this.state = {
            name: "",
            describtion: "",
            url: "",
            price: "",
            successful: false
          };
        }
      
        onChangename = (event) => {
          this.setState({
            name: event.target.value
          });
        }
      
        onChangedescribtion = (event) => {
          this.setState({
            describtion: event.target.value
          });
        }
      
        
      
        onChangeurl = (event) => {
          this.setState({
            url: event.target.value
          });
        }
      
        onChangeprice = (event) => {
          this.setState({
            price: event.target.value
          });
        }
      
        
      
        handleAddProduct = (event) => {
          event.preventDefault();
      
 
  
    
      let product = {
        name :this.state.name ,
        describtion : this.state.describtion, 
        url : this.state.url, 
        price : this.state.price, 
        
      }
  
      ProductService.createProduct (product)
       console.log(this.state.price)
      if (this.state.name && this.state.describtion  && this.state.url && this.state.price ) {
        console.log(this.state.name + " " + this.state.describtion + " " + "" +this.state.url + ""+ this.state.price )
        this.setState({
          successful: true,
          message: "Success -Product Saved Successfully."
        })
      } else {
        this.setState({
          successful: false,
          message: "Not valied"
        })
      }
}
  


  render() {
    return (



      <Grid container spacing={1}>
          
      <Grid item xs={4}/>
      <Grid item xs={5} Style={{backgroundColor:"black"}}>
        <Card className={style.root} style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px",marginTop:150}}>
         <CardContent>
         {/* <Paper variant="outlined"> */}
         <div className="card">
           <form className={style.root} noValidate autoComplete="off" style={{width:'150%'}}onSubmit={this.AddProduct}>
                {!this.state.successful && (
           <Grid container spacing={1}>
                    <Grid item xs={11}>
                      
                    <h3 style={{fontSize:30,color:"black"}}>Add Products</h3>
                  
                     
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl>
                      <FormControl variant="outlined" style={style.formControl} Style={{width:"300%"}}>
                      <InputLabel htmlFor="outlined-age-native-simple">Select Items</InputLabel>
                        <Select
                        native
                        // value={state.age}
                        onChange={this.onChangename}
                        label="Age"
                        inputProps={{
                            name: 'age',
                            id: 'outlined-age-native-simple',
        }}
      >
        <option aria-label="None" value="" />
        <option>tommoto</option>
        <option >beetroot</option>
        <option>Cauli</option>
        <option>mint</option>
        <option>veld grape</option>
        <option>carrot</option>
        <option>chilli</option>
   
      </Select>
    </FormControl>&emsp; &emsp;  
                          
                      {/* <TextField type="text" id="outlined-required" label="Name" variant="outlined" helperText="Enter your name" style={{width:"120%"}} onChange={this.onChangename} /> */}
                      </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp; 
                      <FormControl>
                      <TextField type="" id="outlined-required" label="Available" variant="outlined" helperText="Enter your avaible items" style={{width:"120%"}} onChange={this.onChangeavilable} />
                      </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp;
                      </Grid> 
                      
                    

                      <Grid item xs={12}>
                      <FormControl>
                      <TextField type="" id="outlined-required" label="cover photo URL" variant="outlined" helperText="Enter poultry cover photo URL"  style={{width:"120%"}}onChange={this.onChangeurl} />
                      </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp;
                     

                     
                      <FormControl >
                      <TextField type= "" id="outlined-required" label="Dicribtion" variant="outlined" helperText="Enter discribtion " style={{width:"120%"}} onChange={this.onChangedescribtion}/>
                      </FormControl> &emsp; &emsp; &emsp;  &emsp;  &emsp;
                      </Grid>
                        
                      <Grid item xs={12}>
                      <FormControl >
                      <TextField type= "" id="outlined-required" label="price" variant="outlined" helperText="Enter Poultry  Price " style={{width:"120%"}} onChange={this.onChangeprice}/>
                      </FormControl>
                     {/* </Grid> */}

                     {/* <Paper variant="outlined">  */}
                      {/* <Grid item xs={12}> */}
                      <Button href="/Save" variant="contained"onClick={this.handleAddProduct} style={{backgroundColor:'blue',marginLeft:150}}> <SaveIcon style={{fontSize:20}}/>Add</Button>&emsp; 
                      <Button  href="/Reset"variant="contained" style={{backgroundColor:'#0d47a1'}}> <ReplayIcon style={{fontSize:20}}/>RESET</Button>&emsp;
                      {/* <Button href="/upadate" variant="contained" style={{backgroundColor:'#0d47a1'}}><UpdateIcon style={{fontSize:20}}/>Update</Button>  */}
                     {/* </Paper> */}
                      </Grid>
               </Grid>   
               )}
               {this.state.message && (
             <div>
               <Typography color='#d50000' variant="overline" display="block" gutterBottom> 
                   <strong>{this.state.message}</strong>
               </Typography>
             </div>
           )}
              
              </form>
              </div>
              {/* </Paper> */}
            </CardContent>
      </Card>
      </Grid>
      <Grid item xs={4}/>
    
    </Grid>
      // <Grid container>
      //   <Grid item xs={4}/>
      
      //   <Grid item xs={5}>
      //     <Card style={style.root}>
      //         <CardContent>
      //         <Card style1={style.root1}>
      //         <CardContent>
      //           <form style={{color:"black" }}>
      //             { !this.state.successful &&(
      //             <Grid container spacing={1}>
      //                 <Grid item xs={12}>
      //                   {
      //                     localStorage.getItem("exportin")?(
      //                       <h3 style = {{color: 'black'}}> <AddBoxIcon fontSize = "small"/>  Update Products</h3> 

      //                     ):(<h3 style = {{color: 'black'}}> <AddBoxIcon fontSize = "small"/>  Add New Products</h3> )
      //                   }
                    
                  
                       
      //                 </Grid>
                      
      //                 <Grid item xs={12}>
      //                   <FormControl>
      //                   <TextField required type="text" label="name" variant="outlined" helperText=" Enter Username"  onChange={this.onChangeTitle}/>
      //                   </FormControl> &emsp;&emsp;
      //                   <FormControl >
      //                   <TextField required type="text" label="Price" variant="outlined" helperText="Enter  price"  onChange={this.onChangeEmail}/>
      //                   </FormControl> &emsp;&emsp;
      //                   <Grid/>
      //                   <FormControl >
      //                   <TextField required type="text" label="Address" variant="outlined" helperText=" Enter URL"  onChange={this.onChangeTitle}/>
      //                   </FormControl> &emsp;&emsp;


      //                   <FormControl>
      //                   <TextField
      //     id="outlined-SelectRole"
      //     select
      //     label="SelectRole"
            
      //     SelectProps={{
      //       native: true,
      //     }}
      //     helperText="Please select Role"
      //     variant="outlined"
      //   >

      //    <option value={"Select Role"}>Items</option>
      //    <option value={"Admin"}>Vegitables</option>
      //    <option value={"User"}>Herbs</option>
          

          
         
      //     ))
      //   </TextField> 
      //                   </FormControl> &emsp;&emsp;
                       

                       
 
                      
      //                   <FormControl>
      //                   <TextField required type="text" label="MobileNumer" variant="outlined" helperText="Enter Mobilenumber"  onChange={this.onChangePassword}/>
      //                   </FormControl>
      //                 </Grid>

                     



      //                 <Grid item xs={12}>
      //                   <FormControl>
      //                    < paper varient='outlined'>
      //                     <Button href="/save" varient="contained" style={{backgroundColor:'#1b5e20'}} onClick={this.Booksave}><SaveIcon />SAVE</Button>&emsp;
      //                     <Button href="/reset" varient="contained" style={{backgroundColor:'blue'}}><ReplayIcon/>RESET</Button>&emsp;
      //                     <Button href="/UserList" varient="contained" style={{backgroundColor:'blue'}}><ListIcon/>USERLIST</Button>&emsp;
      //                     </paper>
      //                   </FormControl>
      //                 </Grid>
      //             </Grid>
      //             )}
      //             {
      //               this.state.message && (
      //               <div>
      //                 <Typography color={this.state.successful ? 'primary' : 'error'} variant="overline" display="block" gutterBottom>
      //                     <strong>userProducts successfully</strong>
      //                 </Typography>
                
      //               </div>
      //             )
      //             }
      //           </form>
      //         </CardContent>
      //         </Card>
      //   </CardContent>
      //   </Card>
      //   </Grid>
      //   <Grid item xs={4}/>
      // </Grid>
    );
  }
    
    }
     
    
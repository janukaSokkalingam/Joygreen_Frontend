import axios from 'axios';

const PRODUCT_API_BASE_URL = 'http://localhost:8080/product';

class productservice {

    getAllProduct() {
        return axios.get(PRODUCT_API_BASE_URL);
    }
    createProduct(product){
        return axios.post(PRODUCT_API_BASE_URL , product);
    }
    getProductById(productId) {
        return axios.get(PRODUCT_API_BASE_URL + '/' + productId);
    }
    deleteproductById(id) {
        return axios.delete(PRODUCT_API_BASE_URL + '/' + id);
    }
    updateproductById(id) {
        return axios.put(PRODUCT_API_BASE_URL + '/' + id);
    }
    getAllProductInPage(pageNo,pageSize,sortBy){
        return axios.get(PRODUCT_API_BASE_URL + '/' + 'page?pageNo='+pageNo+'&pageSize='+pageSize+'&sortBy='+sortBy );
    }
    searchProduct(name){
        return axios.get(PRODUCT_API_BASE_URL  + '?name='+name );
    }

}

export default new productservice();

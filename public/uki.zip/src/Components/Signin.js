import React, { Component } from "react";
import IconButton from '@material-ui/core/IconButton';
import { Card, CardContent, Typography, Grid, FormControl, TextField,Button } from '@material-ui/core';
import Cart from "./section/Cart";
import { CenterFocusStrong } from "@material-ui/icons";
// import { Face } from '@material-ui/icons';


const style = {
  root: {
    minWidth: 275,
    backgroundColor:'white',
    marginTop: 60,
    color: '#00000'
  }
}

export default class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      username: "",
      password: "",
      message: ""
    };
  }

  onChangeUsername = (e) => {
    this.setState({
      username: e.target.value
    });
  }

  onChangePassword = (e) => {
    this.setState({
      password: e.target.value
    });
  }

  handleLogin = (e) => {
    e.preventDefault();

    if (this.state.username && this.state.password) {
          console.log("username = " + this.state.username)
          console.log("password = " + this.state.password)
          localStorage.setItem('id', '1');
          localStorage.setItem('username', this.state.username);
          localStorage.setItem('email', 'biru@gmail.com');
          localStorage.setItem('roles', 'ROLE_ADMIN');
          this.props.history.push("/profile");
          window.location.reload();
    } else {
      this.setState({
        message: "Empty username or password"
      })
    }
  }

  render() {
    return (
<center>
      <Card style={{margin:100, border:"2px 5px 8px",boxShadow:"10px 20px 25px gray",width: '25rem',height:'30rem'}}>
    
      {/* <div style={{backgroundColor:"white"}}>
      */}
        
      <Grid container>
        <Grid item xs={2}/>
        <Grid item xs={4}>
          <Card style={style.root}>
              <CardContent>
                <form onSubmit={this.handleLogin}>
                  <Grid container spacing={1}>
                  <Grid item xs={12}>
                  < h1>signin Here</ h1>
                      </Grid>
                      <Grid item xs={12}>
                        {/* <Face style={{ fontSize: 80 }}/> */}
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl >
                          <label htmlFor="username">Username</label>
                          <TextField   variant="outlined" type="text" name="username" value={this.state.username}
                            onChange={this.onChangeUsername}/>
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl >
                          <label htmlFor="password">Password</label>
                          <TextField  variant="outlined"type="password" name="password" value={this.state.password}
                            onChange={this.onChangePassword}/>
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                        <Button variant="outlined" color="primary" >
        signin
      </Button>
                        </FormControl>
                      </Grid>
                  </Grid>
                  {this.state.message && (
                    <div>
                      <Typography color='error' variant="overline" display="block" gutterBottom>
                          <strong>{this.state.message}</strong>
                      </Typography>
                    </div>
                    
                  )}
                </form>
              </CardContent>
        </Card>
        
        </Grid>
        <Grid item xs={4}/>
      </Grid>
      
      {/* </div> */}
    
      </Card>
     </center>
    );
  }
}



 

 